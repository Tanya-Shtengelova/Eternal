import csv
from web3 import Web3
import json

def read_csv_data(filepath):
    data = []
    with open(filepath, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)  # Читает как словарь (ключ-значение)
        for row in reader:
            data.append(row)
    return data


def send_data_to_contract_Cust(data):
    for row in data:
        tx = contract.functions.addRecord(row["CustomerID"], row["CustomerTypeID"], row["Name"],
        row["DateOfBirth"], row["RegistrationDate"], row["TIN"], row["ContactInfo"]).buildTransaction({
            'chainId': 15, #ID сети
            'nonce': nonce,
            'gas': 6000000, #Поставьте достаточное количество газа
            'gasPrice': w3.eth.gas_price,
            'from': account.address,
        })
        signed_txn = account.signTransaction(tx)
        tx_hash = w3.eth.sendRawTransaction(signed_txn.rawTransaction)
        print("Transaction hash:", w3.toHex(tx_hash))
        nonce += 1

def send_data_to_contract_Prod(data):
    #CreditProductID,ProductName,InterestRate,MaxLoanAmount,MinRepaymentTerm,CollateralRequired
    for row in data:
        tx = contract.functions.addRecord(row["CreditProductID"], row["ProductName"], row["InterestRate"],
        row["MaxLoanAmount"], row["MaxLoanAmount"], row["MinRepaymentTerm"], row["CollateralRequired"])
        .buildTransaction({
            'chainId': 15, #ID сети
            'nonce': nonce,
            'gas': 6000000, #Поставьте достаточное количество газа
            'gasPrice': w3.eth.gas_price,
            'from': account.address,
        })
        signed_txn = account.signTransaction(tx)
        tx_hash = w3.eth.sendRawTransaction(signed_txn.rawTransaction)
        print("Transaction hash:", w3.toHex(tx_hash))
        nonce += 1

def send_data_to_contract_Contr(data):
    #CreditAgreementID,CustomerID,CreditProductID,AgreementDate,LoanAmount,LoanTerm,InterestRate
    for row in data:
        tx = contract.functions.addRecord(row["CreditAgreementID"], row["CustomerID"], row["CreditProductID"],
        row["AgreementDate"], row["LoanAmount"], row["LoanTerm"], row["InterestRate"])
        .buildTransaction({
            'chainId': 15, #ID сети
            'nonce': nonce,
            'gas': 6000000, #Поставьте достаточное количество газа
            'gasPrice': w3.eth.gas_price,
            'from': account.address,
        })
        signed_txn = account.signTransaction(tx)
        tx_hash = w3.eth.sendRawTransaction(signed_txn.rawTransaction)
        print("Transaction hash:", w3.toHex(tx_hash))
        nonce += 1

def send_data_to_contract_Transact(data):
    #TransactionID,CustomerID,CreditAgreementID,TransactionDate,TransactionAmount,TransactionTypeID
    for row in data:
        tx = contract.functions.addRecord(row["TransactionID"], row["CustomerID"], row["CreditAgreementID"],
        row["TransactionDate"], row["TransactionAmount"], row["TransactionTypeID"])
        .buildTransaction({
            'chainId': 15, #ID сети
            'nonce': nonce,
            'gas': 6000000, #Поставьте достаточное количество газа
            'gasPrice': w3.eth.gas_price,
            'from': account.address,
        })
        signed_txn = account.signTransaction(tx)
        tx_hash = w3.eth.sendRawTransaction(signed_txn.rawTransaction)
        print("Transaction hash:", w3.toHex(tx_hash))
        nonce += 1

url = "HTTP://127.0.0.1:8545"
with open("abi.json", 'r') as file:
        abi = json.load(file)
storage = ""
address = web3.Web3.to_checksum_address("0xE90F67394351f0168c2D0ef781302Ed060A14a3E")#адрес контракта

self.w3 = web3.Web3(web3.Web3.HTTPProvider(self.url))
self.w3.eth.defaultAccount = self.w3.eth.accounts[0]
self.storage = self.w3.eth.contract(address=self.address, abi=self.abi)

csv_data = read_csv_data('Customers.csv')
send_data_to_contract_Cust(csv_data)

csv_data = read_csv_data('CreditProducts.csv')
send_data_to_contract_Prod(csv_data)

csv_data = read_csv_data('CreditAgreements.csv')
send_data_to_contract_Contr(csv_data)

csv_data = read_csv_data('CreditTransacrtions.csv')
send_data_to_contract_Transact(csv_data)
